# AI Vibe Coder - Complete WordPress Plugin Package

This document provides a complete overview of the AI Vibe Coder plugin package ready for upload and testing on WordPress hosting sites like InfinityFree.

## Package Contents

The plugin package includes all necessary files for a fully functional AI-powered coding assistant. The file structure has been organized to meet WordPress plugin directory standards and ensure proper functionality across all WordPress installations.

```
ai-vibe-coder/
├── ai-vibe-coder.php              # Main plugin file (entry point)
├── readme.txt                     # WordPress.org plugin readme
├── uninstall.php                  # Cleanup script for plugin removal
├── INSTALLATION.txt               # Detailed installation guide
├── TESTING.txt                    # Comprehensive testing checklist
├── assets/
│   ├── index.php                  # Directory protection
│   ├── css/
│   │   ├── admin.css              # Admin dashboard styles
│   │   └── frontend.css           # Frontend shortcode styles
│   └── js/
│       └── admin.js               # Admin JavaScript functionality
├── includes/
│   ├── index.php                  # Directory protection
│   ├── class-api-handler.php      # AI API connection management
│   ├── class-code-generator.php   # Code generation logic
│   ├── class-content-generator.php # Content creation logic
│   └── class-snippet-manager.php  # Snippet database management
├── languages/
│   └── ai-vibe-coder.pot          # Translation template
└── templates/
    ├── index.php                  # Directory protection
    ├── dashboard.php              # Main dashboard template
    ├── generator.php              # Code generator page
    ├── snippets.php               # Snippets library template
    ├── content.php                # Content AI page template
    ├── settings.php               # Settings page template
    └── frontend-generator.php     # Frontend shortcode template
```

## Quick Installation Steps

For immediate testing on InfinityFree or any WordPress hosting, follow these streamlined steps that will have the plugin operational within minutes rather than hours.

### Step 1: Create the ZIP Package

On your local computer, navigate to the ai-vibe-coder folder containing all the plugin files. Select every file and folder inside, right-click, and choose "Send to Compressed (zipped) folder" on Windows or "Compress" on Mac. This creates ai-vibe-coder.zip with the correct internal directory structure that WordPress expects. The critical aspect here is ensuring the ai-vibe-coder.php file sits directly in the ZIP root, not inside a subfolder, as this is a common installation failure point.

### Step 2: Upload via WordPress Admin

Log into your WordPress dashboard at your InfinityFree site and navigate to Plugins, then Add New. Click the Upload Plugin button at the top of the page, choose the ai-vibe-coder.zip file you created, and click Install Now. After installation completes, click Activate Plugin. If you encounter upload errors, the file size may exceed your hosting limits; in this case, use the File Manager method described in INSTALLATION.txt.

### Step 3: Configure API Settings

Once activated, locate "AI Vibe Coder" in your admin sidebar and click Settings. You must configure an API key before using the plugin. For OpenAI, select "OpenAI (GPT)" from the provider dropdown, paste your API key, and choose your preferred model. GPT-4 offers the highest quality output while GPT-3.5 Turbo provides faster responses at lower cost. Enter your API key carefully without leading or trailing spaces, then click Save Settings followed by Test Connection to verify everything works correctly.

### Step 4: Test with the Frontend Shortcode

After successful API configuration, create a new WordPress page and add a shortcode block containing exactly [ai_vibe_coder]. Publish the page and view it on the frontend. You should see the AI Code Generator interface ready to accept prompts. This shortcode enables visitors to your site to generate code without accessing the admin area, making the plugin suitable for offering AI coding services to clients or site users.

## Shortcode Usage Guide

The AI Vibe Coder plugin includes a powerful frontend shortcode that embeds the full code generator interface directly into any WordPress page, post, or widget. This feature transforms your WordPress site into a functional AI coding assistant platform.

### Basic Shortcode Usage

The primary shortcode [ai_vibe_coder] requires no parameters and displays the complete code generator interface. When visitors access the page containing this shortcode, they see a responsive interface with code type selection, prompt input, and code output areas. The interface functions identically to the admin version, enabling users to generate shortcodes, widgets, functions, CSS, JavaScript, custom post types, and taxonomies through natural language descriptions.

The generated interface includes type selector buttons for different code categories, a prominent prompt textarea with example prompts, a generate button with loading states, and a copy-to-clipboard feature for generated code. All generated code appears in a syntax-highlighted output area that users can immediately copy and use in their WordPress projects.

### Customization Options

The shortcode supports several parameters for customization, though the default configuration works for most use cases. The type parameter accepts values like shortcode, widget, function, css, javascript, post_type, or taxonomy to preset the code type selector. For example, [ai_vibe_coder type="css"] opens the interface with CSS selected, guiding users toward generating stylesheets. This parameter proves useful when embedding the generator for specific purposes, such as creating a dedicated CSS generation page or a JavaScript helper tool.

### Practical Applications

The frontend shortcode opens numerous practical applications beyond personal use. Web development agencies can offer AI coding services to clients through their existing WordPress site. Educational platforms can provide coding assistance to students without requiring admin access. Freelancers can showcase AI-assisted development capabilities to attract clients. Content sites can add interactive tools that increase engagement and time-on-site metrics.

For InfinityFree users specifically, the free hosting environment may have API call limitations, so test generation carefully and monitor your OpenAI or Anthropic usage to avoid unexpected charges. The plugin works identically regardless of hosting environment, with the only potential variance being PHP execution time limits on long AI responses.

## Feature Overview

The AI Vibe Coder plugin delivers a comprehensive suite of AI-powered development tools through an intuitive WordPress interface designed for both novice and experienced developers.

### Code Generator Module

The code generator forms the plugin's core functionality, transforming natural language descriptions into working WordPress code. Users describe what they need in plain English, and the AI produces properly formatted, secure, and standards-compliant code. The generator supports seven distinct code types, each optimized for specific use cases.

Shortcode generation creates custom shortcode functions following WordPress best practices with proper escaping, sanitization, and documentation. The generated shortcodes include example usage and can be immediately deployed on any WordPress site. Widget generation produces complete WP_Widget subclass implementations with form methods, update methods, and widget display logic. Custom function generation creates reusable PHP functions with appropriate hooks and filters. CSS generation outputs responsive, modern styles following BEM naming conventions and utilizing CSS custom properties. JavaScript generation produces clean, standards-compliant scripts compatible with WordPress's jQuery noConflict mode. Custom post type generation creates complete register_post_type calls with all appropriate labels and arguments. Custom taxonomy generation produces register_taxonomy calls for organizing content.

### Content AI Module

Beyond code generation, the plugin includes powerful content creation capabilities. The content AI generates blog posts, pages, excerpts, titles, and meta descriptions through natural language prompts. Users describe the content topic and desired tone, and the AI produces SEO-optimized HTML-formatted content ready for publication. Content improvement features allow users to paste existing content and request enhancements for clarity, engagement, or SEO optimization. Translation capabilities enable content creation in multiple languages for international audiences.

### Snippets Library

All generated code automatically saves to a searchable snippets library where users can organize, tag, and manage their code collection. Each snippet stores the original prompt, generated code, creation date, and usage statistics. The library supports deployment workflows where snippets can be marked as deployed for production tracking. Export functionality allows snippets to be shared between sites or backed up for safekeeping.

### Security Implementation

The plugin implements multiple security layers to ensure safe operation in production environments. All AJAX requests require nonce verification to prevent CSRF attacks. User capability checks restrict admin functions to authorized users only. Input sanitization uses WordPress native functions like sanitize_text_field and esc_html to prevent XSS vulnerabilities. Output escaping protects against injection attacks in all displayed content. The snippets database uses prepared statements for all queries to prevent SQL injection. API keys encrypt using WordPress options API and never transmit except directly to AI providers.

## Configuration Reference

The settings page provides granular control over plugin behavior and AI model parameters. Understanding these settings enables optimal performance for specific use cases and budget constraints.

### API Provider Settings

The provider selection determines which AI service processes your requests. OpenAI offers GPT-4, GPT-4 Turbo, and GPT-3.5 Turbo models with well-documented APIs and extensive training data. Anthropic provides Claude models including Sonnet 4 and Opus 4, known for excellent coding capabilities and instruction following. The choice between providers affects response quality, speed, and cost based on your specific use patterns.

Model selection within each provider offers quality versus speed tradeoffs. GPT-4 delivers the highest quality output but costs more per token and processes requests more slowly. GPT-3.5 Turbo provides adequate quality at lower cost and faster speeds. Claude Opus 4 offers similar capability to GPT-4 while Claude Sonnet 4 balances quality and efficiency. For most code generation tasks, GPT-4 or Claude Sonnet 4 provide optimal results, while high-volume content generation may benefit from faster, less expensive models.

The temperature setting controls output randomness with lower values producing more predictable, focused responses and higher values generating more creative, varied outputs. For code generation, temperatures between 0.3 and 0.7 work best, producing reliable code without excessive creativity that might introduce errors. Content generation benefits from higher temperatures (0.7-0.9) for more engaging, varied prose.

The max tokens setting limits response length, with higher values enabling longer, more detailed outputs. Code generation typically requires 1000-3000 tokens depending on complexity, while content generation may need 2000-4000 tokens for substantial articles. Setting this value appropriately prevents truncated responses while avoiding unnecessary costs from excessive token usage.

### Feature Toggle Settings

Individual feature toggles control which modules appear in the admin interface. Disabling unused features simplifies the interface for users who only need specific functionality and may slightly improve performance by reducing loaded code. The auto-save toggle determines whether generated code automatically saves to the snippets library or requires manual saving. Leaving this enabled captures all generated code for future reference while disabling it reduces database operations for users who only need immediate code copies.

## Testing Procedures

Systematic testing ensures all plugin features function correctly on your specific hosting environment. The TESTING.txt file provides a comprehensive checklist, but these core tests verify basic functionality.

### Dashboard Verification

After activation, navigate to AI Vibe Coder, then Dashboard. The page should display statistics cards showing total snippets, deployed count, and API status. All quick action cards should appear with clickable links to respective features. If any elements fail to display, check PHP error logs for initialization failures.

### Code Generation Test

Navigate to Code Generator, select "Shortcode" as the type, and enter the prompt: "Create a simple button shortcode with red background and white text." Click Generate Code with AI and wait for the response. Successful generation produces PHP code in a syntax-highlighted output area. If the generation fails or hangs beyond 60 seconds, check your API configuration and connection status.

### Shortcode Embedding Test

Create a new WordPress page containing only the shortcode [ai_vibe_coder] and publish it. View the page on the frontend to verify the generator interface displays correctly. Attempt a code generation from the frontend to confirm full functionality. Frontend operation validates that the plugin correctly handles public-facing requests and doesn't expose admin-only functionality.

## Support and Resources

If issues arise during installation or testing, several resources provide assistance. Review the INSTALLATION.txt troubleshooting section for common hosting-specific problems. The TESTING.txt checklist identifies potential configuration issues affecting specific features. Check your InfinityFree hosting account for any API call limitations or PHP configuration restrictions that might affect plugin performance.

For API-related issues, verify your OpenAI or Anthropic account has sufficient credits and the API key has proper permissions. Test the API connection directly through the settings page using the Test Connection button. Review your AI provider's usage dashboard to confirm requests are reaching their servers and receiving responses.

Plugin conflicts with other installed extensions can cause unexpected behavior. Test the plugin with all other plugins temporarily deactivated and with a default theme active. If issues resolve in this clean environment, reactivate plugins one-by-one to identify the conflicting extension. Report persistent issues with details about your WordPress version, PHP version, hosting environment, and specific error messages encountered.
